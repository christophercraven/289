<?php
class Colors extends \Phalcon\Mvc\Model
{
    public function getSource()
    {
		// 145 colors in database
        return "colors_col";
    }

}