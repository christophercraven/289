<?php
class Apps extends \Phalcon\Mvc\Model
{
    public function getSource()
    {	
		// Apps are the same as "Projects"
        return "app_app";
    }

}