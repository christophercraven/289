<?php
class Fruits extends \Phalcon\Mvc\Model
{
    public function getSource()
    {	
		// 78 fruits are in database
        return "fruits_fru";
    }

}