<?php
class Users extends \Phalcon\Mvc\Model
{
    public function getSource()
    {
        return "users_usr";
    }

}