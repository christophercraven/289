<?php



class TeamsController extends ControllerBase
{
    public function initialize()
    {
        $this->tag->setTitle('Your Teams');
        parent::initialize();
    }
    public function indexAction()
    {
    }


}