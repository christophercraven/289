<?php echo '<h1>Nginx server misconfiguration</h1>';
